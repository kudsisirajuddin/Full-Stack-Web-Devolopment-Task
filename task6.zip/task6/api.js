const BASE_URL = "https://fakestoreapi.com";

// GET - Fetch all products
export async function fetchProducts() {
    const response = await fetch(`${BASE_URL}/products`);

    if (!response.ok) {
        throw new Error(`HTTP Error: ${response.status}`);
    }

    return await response.json();
}

// POST - Add new product
export async function addProduct(product) {
    const response = await fetch(`${BASE_URL}/products`, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(product)
    });

    if (!response.ok) {
        throw new Error("Failed to add product");
    }

    return await response.json();
}

// DELETE - Delete product
export async function deleteProduct(id) {
    const response = await fetch(`${BASE_URL}/products/${id}`, {
        method: "DELETE"
    });

    if (!response.ok) {
        throw new Error("Failed to delete product");
    }

    return await response.json();
}