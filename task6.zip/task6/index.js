import {
    fetchProducts,
    addProduct,
    deleteProduct
} from "./api.js";


// ===============================
// GLOBAL VARIABLES
// ===============================

let products = [];

let filteredProducts = [];

let currentPage = 1;

const productsPerPage = 8;

let cart = JSON.parse(localStorage.getItem("cart")) || [];


// ===============================
// LOAD PRODUCTS
// ===============================

async function loadProducts() {

    showSpinner(true);

    hideError();

    try {

        products = await fetchProducts();

        applyFilters();

    } catch (error) {

        console.error(error);

        showError(
            "Unable to load products. Please check your internet connection."
        );

    } finally {

        showSpinner(false);

    }
}


// ===============================
// APPLY FILTERS
// ===============================

function applyFilters() {

    const searchValue =
        document
            .getElementById("search")
            .value
            .toLowerCase()
            .trim();

    const category =
        document.getElementById("filter").value;

    const sort =
        document.getElementById("sort").value;


    // Search + Category Filter

    filteredProducts = products.filter(product => {

        const matchesSearch =
            product.title
                .toLowerCase()
                .includes(searchValue);

        const matchesCategory =
            category === "all" ||
            product.category === category;

        return matchesSearch && matchesCategory;

    });


    // ===============================
    // SORTING
    // ===============================

    if (sort === "price-low") {

        filteredProducts.sort(
            (a, b) => a.price - b.price
        );

    }

    else if (sort === "price-high") {

        filteredProducts.sort(
            (a, b) => b.price - a.price
        );

    }

    else if (sort === "name") {

        filteredProducts.sort(
            (a, b) =>
                a.title.localeCompare(b.title)
        );

    }


    // Whenever filter/search/sort changes,
    // return to first page

    currentPage = 1;

    renderProducts();

}


// ===============================
// RENDER PRODUCTS
// ===============================

function renderProducts() {

    const container =
        document.getElementById("products");

    container.innerHTML = "";


    const start =
        (currentPage - 1) * productsPerPage;

    const end =
        start + productsPerPage;


    const pageProducts =
        filteredProducts.slice(start, end);


    // No products found

    if (pageProducts.length === 0) {

        container.innerHTML =
            "<p>No products found.</p>";

        updatePagination();

        return;

    }


    // Create product cards

    pageProducts.forEach(product => {

        const card =
            document.createElement("div");

        card.className = "product-card";


        card.innerHTML = `

            <img
                src="${product.image}"
                alt="${product.title}"
            >

            <h3>
                ${product.title}
            </h3>

            <p class="category">
                ${product.category}
            </p>

            <p class="price">
                ₹${product.price}
            </p>

            <div class="card-buttons">

                <button
                    class="cart-btn"
                    data-action="cart"
                    data-id="${product.id}"
                >
                    Add to Cart
                </button>

                <button
                    class="delete-btn"
                    data-action="delete"
                    data-id="${product.id}"
                >
                    Delete
                </button>

            </div>

        `;


        // ===============================
        // CART BUTTON
        // ===============================

        card
            .querySelector('[data-action="cart"]')
            .addEventListener(
                "click",
                function () {

                    addToCart(product.id);

                }
            );


        // ===============================
        // DELETE BUTTON
        // ===============================

        card
            .querySelector('[data-action="delete"]')
            .addEventListener(
                "click",
                function () {

                    handleDelete(product.id);

                }
            );


        container.appendChild(card);

    });


    updatePagination();

}


// ===============================
// DELETE PRODUCT
// ===============================

async function handleDelete(id) {

    const confirmDelete =
        confirm("Remove this product?");


    if (!confirmDelete) {

        return;

    }


    try {

        // Send DELETE request to API

        await deleteProduct(id);


        // Remove product from local array

        products =
            products.filter(
                product => product.id !== id
            );


        // Re-render products

        applyFilters();


    } catch (error) {

        console.error(error);

        alert(
            "Delete failed. Please try again."
        );

    }

}


// ===============================
// ADD PRODUCT
// ===============================

function setupAddProductForm() {

    document
        .getElementById("add-form")
        .addEventListener(
            "submit",
            async function (event) {

                event.preventDefault();


                const title =
                    document
                        .getElementById("title")
                        .value
                        .trim();


                const price =
                    parseFloat(
                        document
                            .getElementById("price")
                            .value
                    );


                const category =
                    document
                        .getElementById("category")
                        .value;


                const newProduct = {

                    title: title,

                    price: price,

                    category: category,

                    image:
                        "https://via.placeholder.com/150"

                };


                try {

                    // POST request

                    const created =
                        await addProduct(newProduct);


                    // Add created product
                    // to beginning of array

                    products.unshift(created);


                    // Clear form

                    event.target.reset();


                    // Show updated products

                    applyFilters();


                    alert(
                        "Product added successfully!"
                    );


                } catch (error) {

                    console.error(error);

                    alert(
                        "Could not add product. Please try again."
                    );

                }

            }
        );

}


// ===============================
// SEARCH
// ===============================

function setupSearch() {

    document
        .getElementById("search")
        .addEventListener(
            "input",
            applyFilters
        );

}


// ===============================
// CATEGORY FILTER
// ===============================

function setupCategoryFilter() {

    document
        .getElementById("filter")
        .addEventListener(
            "change",
            applyFilters
        );

}


// ===============================
// SORT
// ===============================

function setupSort() {

    document
        .getElementById("sort")
        .addEventListener(
            "change",
            applyFilters
        );

}


// ===============================
// PAGINATION
// ===============================

function setupPagination() {

    // Previous button

    document
        .getElementById("prev")
        .addEventListener(
            "click",
            function () {

                if (currentPage > 1) {

                    currentPage--;

                    renderProducts();

                }

            }
        );


    // Next button

    document
        .getElementById("next")
        .addEventListener(
            "click",
            function () {

                const totalPages =
                    Math.ceil(
                        filteredProducts.length /
                        productsPerPage
                    );


                if (currentPage < totalPages) {

                    currentPage++;

                    renderProducts();

                }

            }
        );

}


// ===============================
// UPDATE PAGINATION
// ===============================

function updatePagination() {

    const totalPages =
        Math.ceil(
            filteredProducts.length /
            productsPerPage
        );


    const pageNumber =
        document.getElementById("page-number");


    const previousButton =
        document.getElementById("prev");


    const nextButton =
        document.getElementById("next");


    pageNumber.textContent =
        `Page ${currentPage} of ${totalPages || 1}`;


    previousButton.disabled =
        currentPage === 1;


    nextButton.disabled =
        currentPage >= totalPages ||
        totalPages === 0;

}


// ===============================
// CART
// ===============================

function addToCart(id) {

    const product =
        products.find(
            product => product.id === id
        );


    if (!product) {

        return;

    }


    cart.push(product);


    localStorage.setItem(
        "cart",
        JSON.stringify(cart)
    );


    updateCartCount();


    alert(
        "Product added to cart!"
    );

}


// ===============================
// UPDATE CART COUNT
// ===============================

function updateCartCount() {

    const cartCount =
        document.getElementById("cart-count");


    cartCount.textContent =
        cart.length;

}


// ===============================
// LOADING SPINNER
// ===============================

function showSpinner(visible) {

    const spinner =
        document.getElementById("spinner");


    spinner.style.display =
        visible ? "block" : "none";

}


// ===============================
// ERROR MESSAGE
// ===============================

function showError(message) {

    const error =
        document.getElementById("error-msg");


    error.textContent =
        message;


    error.style.display =
        "block";

}


function hideError() {

    const error =
        document.getElementById("error-msg");


    error.style.display =
        "none";

}


// ===============================
// START APPLICATION
// ===============================

document.addEventListener(
    "DOMContentLoaded",
    async function () {

        // Load existing cart count

        updateCartCount();


        // Setup all event listeners

        setupAddProductForm();

        setupSearch();

        setupCategoryFilter();

        setupSort();

        setupPagination();


        // Fetch products from API

        await loadProducts();

    }
);